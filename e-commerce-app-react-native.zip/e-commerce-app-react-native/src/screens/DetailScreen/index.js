export * from "./DetailScreen";
