const banners = [
  {
    id: "9471645183",
    imageUrl: require("../assets/Images/banner1.jpg"),
  },
  {
    id: "5656210978",
    imageUrl: require("../assets/Images/banner6.jpg"),
  },
  {
    id: "044416421",
    imageUrl: require("../assets/Images/banner3.jpg"),
  },
  {
    id: "218716591",
    imageUrl: require("../assets/Images/banner5.jpg"),
  },
  {
    id: "218716523",
    imageUrl: require("../assets/Images/banner4.jpg"),
  },
];

export default banners;
