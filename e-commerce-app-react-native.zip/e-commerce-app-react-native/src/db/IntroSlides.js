//slide
const slides = [
  {
    id: 1,
    lable: "Mua may mắn",
    subtitle: "Tìm loại đá yêu thích",
    des:
      "Việc lựa chọn một vòng đá phù hợp đem lại lợi ích rất lớn trong sự nghiệp, tình cảm, tiền tài",
    imageUrl: require("../assets/Images/slide1.png"),
  },
  {
    id: 2,
    lable: "Cầu bình an",
    subtitle: "Sản phẩm chất lượng",
    des:
      "Giúp  tăng sự tự tin, đầu óc minh mẫn sáng suốt, giải quyết vấn đề cách linh hoạt thông suốt",
    imageUrl: require("../assets/Images/slide2.png"),
  },
  {
    id: 3,
    lable: "Mang hạnh phúc về",
    subtitle: "Bạn còn chần chừ gì nữa?",
    des: "Hãy tìm ngay cho mình sự may mắn, hạnh phúc tại CatTuong ",
    imageUrl: require("../assets/Images/slide3.png"),
  },
];
export default slides;
